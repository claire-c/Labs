def number_of_bank_accounts( accounts )
  return accounts.length()
end

def first_bank_account_holder( accounts )
  return accounts.first()[:holder_name]
end

def bank_account_owner_names( accounts )
  names = []
  for account in accounts
    names << account[:holder_name]
  end
  return names
end

def filter_accounts( type, accounts )
  filtered_accounts = []
  for account in accounts
    if ( account[:type] == type )
      filtered_accounts.push( account )
    end
  end
  return filtered_accounts
end

def total_cash_in_bank( type=nil, accounts )
  if type != nil
    accounts = filter_accounts( type, accounts )
  end

  sum = 0
  for account in accounts
    sum += account[:amount]
  end

  return sum
end

def average_bank_account_value(accounts)
  return total_cash_in_bank(accounts) / number_of_bank_accounts(accounts)
end

def find_accounts_by_risk(risk_level, accounts)
  risky_accounts = []
  for account in accounts
    risk = account[:stats][:risk_level]
    risky_accounts << account if (risk == risk_level)
  end

  return bank_account_owner_names(risky_accounts)
end

def largest_bank_account_holder_by_type( type, accounts)
  accounts = filter_accounts( type, accounts )
  largest_account = accounts.first

  for account in accounts
    if account[:amount] > largest_account[:amount]
      largest_account = account
    end
  end

  return largest_account[:holder_name]
end

def largest_bank_account_holder( accounts )
  largest_account = accounts.first

  for account in accounts
    if account[:amount] > largest_account[:amount]
      largest_account = account
    end
  end

  return largest_account[:holder_name]
end
