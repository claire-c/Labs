# Bank: Functions, Array, Hashes, Loops Exercise

We are working for a mega corporation bank who want us to write an app to report back some interesting information about their customers and accounts.

[i:]Give out the start point code.

Explain that:

- There is a spec file with expectations and a functions file to be completed.
- The first 6 tests are there as a skeleton
- The last 3 tests need fully completed
