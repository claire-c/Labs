def number_of_bank_accounts( accounts )

end
